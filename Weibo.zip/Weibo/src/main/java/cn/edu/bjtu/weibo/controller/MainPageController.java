package cn.edu.bjtu.weibo.controller;

public class MainPageController {

}
