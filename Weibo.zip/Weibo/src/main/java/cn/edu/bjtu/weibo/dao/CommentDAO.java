package cn.edu.bjtu.weibo.dao;

import cn.edu.bjtu.weibo.model.Comment;

public interface CommentDAO {
	String getComment(String commentid);
	String getTopicUserNumber(String commentid);
	String getOwner(String commentid);
	String getTime(String commentid);
	
	boolean addCommentToWeibo(String userId,String weiboId,Comment comment);
	boolean addCommentToComment(String userId,String commentId,Comment comment);
	
}
