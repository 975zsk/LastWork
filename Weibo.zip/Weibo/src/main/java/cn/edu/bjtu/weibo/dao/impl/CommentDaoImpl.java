package cn.edu.bjtu.weibo.dao.impl;

import cn.edu.bjtu.weibo.dao.CommentDAO;
import cn.edu.bjtu.weibo.model.Comment;

public class CommentDaoImpl implements CommentDAO{

	@Override
	public String getComment(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTopicUserNumber(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOwner(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTime(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addCommentToWeibo(String userId, String weiboId, Comment comment) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addCommentToComment(String userId, String commentId, Comment comment) {
		// TODO Auto-generated method stub
		return false;
	}

}
