package cn.edu.bjtu.weibo.model;

public class Picture {
	public String picurl;

	public String getPicurl() {
		return picurl;
	}

	public void setPicurl(String picurl) {
		this.picurl = picurl;
	}
}
