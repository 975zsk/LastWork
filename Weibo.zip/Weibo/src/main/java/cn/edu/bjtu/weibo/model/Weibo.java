package cn.edu.bjtu.weibo.model;

public class Weibo extends BaseContent{
	private int forwardNumber;

	public int getForwardNumber() {
		return forwardNumber;
	}

	public void setForwardNumber(int forwardNumber) {
		this.forwardNumber = forwardNumber;
	}
	
}
