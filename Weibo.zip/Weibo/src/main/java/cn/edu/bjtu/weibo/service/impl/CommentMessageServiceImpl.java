package cn.edu.bjtu.weibo.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import cn.edu.bjtu.weibo.dao.CommentDAO;
import cn.edu.bjtu.weibo.dao.impl.CommentDaoImpl;
import cn.edu.bjtu.weibo.model.Comment;
import cn.edu.bjtu.weibo.service.CommentMessageService;

public class CommentMessageServiceImpl implements CommentMessageService{

	@Override
	public boolean CommentToWeibo(String userId, String weiboId, String comment) {
		// TODO Auto-generated method stub
		Comment cm= new Comment();
		
		cm.setCommentNumber(0);
		cm.setContent(comment);
		cm.setLike(0);
		
		Date date = new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String time=format.format(date);
	    cm.setDate(time);
	    
	    CommentDAO cmdao = new CommentDaoImpl();
	    cmdao.addCommentToWeibo(userId, weiboId, cm);
		return true;
	}

	@Override
	public boolean CommentToComment(String userId, String CommentId, String comment) {
		// TODO Auto-generated method stub
        Comment cm= new Comment();
		
		cm.setCommentNumber(0);
		cm.setContent(comment);
		cm.setLike(0);
		
		Date date = new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String time=format.format(date);
	    cm.setDate(time);
	    
	    CommentDAO cmdao = new CommentDaoImpl();
	    cmdao.addCommentToComment(userId, CommentId, cm);
		return true;
	}

}
